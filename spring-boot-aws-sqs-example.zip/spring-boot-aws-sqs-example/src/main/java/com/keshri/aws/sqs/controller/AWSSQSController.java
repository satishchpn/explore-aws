package com.keshri.aws.sqs.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.model.SendMessageRequest;

import io.awspring.cloud.messaging.listener.annotation.SqsListener;

@RestController
public class AWSSQSController {

	Logger logger = LoggerFactory.getLogger(AWSSQSController.class);

	@Autowired
	AmazonSQSAsync amazonSQSAsync;

	@Value("${sqs.queue.name}")
	private String sqsQueueName;

	@GetMapping("/")
	public String welcome() {
		return "Hi Keshri - Welcome to AWS";
	}

	@GetMapping("/send/{payload}")
	public String sendMessgeToSQSQueue(@PathVariable String payload) {
		try {
			amazonSQSAsync
					.sendMessage(new SendMessageRequest().withMessageBody(payload).withMessageGroupId("keshri-group-id")
							.withMessageDeduplicationId(String.valueOf(System.currentTimeMillis())));
			logger.info("Message Sent to SQS Queue : {}", payload);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return payload;
	}

	@SqsListener(value = { "keshri-queue.fifo" })
	public void consumeMessageFromSQSQueue(String message) {
		System.out.println("hello " + message);
		logger.info("Message Received from SQS Queue {}" + message);
	}
}
