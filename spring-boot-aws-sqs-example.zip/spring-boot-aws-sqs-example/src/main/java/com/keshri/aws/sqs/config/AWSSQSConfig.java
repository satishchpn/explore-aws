
package com.keshri.aws.sqs.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;

import io.awspring.cloud.messaging.config.SimpleMessageListenerContainerFactory;

@Configuration
public class AWSSQSConfig {

	@Value("${aws.region}")
	private String awsRegion;

	@Value("${sqs.endpoint.url}")
	private String serviceEndPoint;

	@Value("${aws.access.key.id}")
	private String accessKey;

	@Value("${aws.secret.access.key}")
	private String secretKey;

	@Value("${sqs.queue.name}")
	private String sqsQueueName;

	@Primary
	@Bean
	public AmazonSQSAsync amazonSQSAsync() {
		BasicAWSCredentials awsCreds = new BasicAWSCredentials(accessKey, secretKey);
		AmazonSQSAsyncClientBuilder builder = AmazonSQSAsyncClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(awsCreds));
		builder.setEndpointConfiguration(new EndpointConfiguration(serviceEndPoint, awsRegion));
		return builder.build();
	}

	@Bean
	public SimpleMessageListenerContainerFactory simpleMessageListenerContainerFactory(AmazonSQSAsync amazonSQSAsync) {
		SimpleMessageListenerContainerFactory factory = new SimpleMessageListenerContainerFactory();
		factory.setAmazonSqs(amazonSQSAsync);
		return factory;
	}

}
