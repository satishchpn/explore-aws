package com.keshri.aws.rds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.keshri.aws.rds.controller.repository.EmployeeRepository;
import com.keshri.aws.rds.entity.Employee;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;

	@GetMapping("/")
	public String welcome() {
		return "Hi Keshri - Welcome to AWS";
	}

	@PostMapping("/employee")
	public Employee saveEmployee(@RequestBody Employee employee) {
		return employeeRepository.save(employee);
	}

	@GetMapping("/employee/{employeeId}")
	public Employee getEmployee(@PathVariable Integer employeeId) {
		return employeeRepository.findById(employeeId)
				.orElseThrow(() -> new RuntimeException("Employee Not Found for given EmployeeId"));
	}

	@GetMapping("/employee")
	public List<Employee> getEmployees() {
		return employeeRepository.findAll();
	}

	@PutMapping("/employee")
	public Employee getEmployee(@RequestBody Employee employee) {
		if (employeeRepository.existsById(employee.getEmployeeId()))
			return employeeRepository.save(employee);
		else
			throw new RuntimeException("No Employee Found with this data");
	}

	@DeleteMapping("/employee")
	public String deleteEmployee(@RequestBody Employee employee) {
		try {
			employeeRepository.delete(employee);
			return "Employee Deleted !!!";
		} catch (Exception e) {
			throw new RuntimeException("Something went wrong !!!", e);
		}
	}

}
