package com.keshri.aws.rds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAwsRdsMysqlAsmExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAwsRdsMysqlAsmExampleApplication.class, args);
	}

}
