import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UniversitiesService {

  constructor(private http: HttpClient) { }

  public universitiesList() {
    return this.http.get("http://universities.hipolabs.com/search?country=india");
  }
}
