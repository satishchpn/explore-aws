import { Component, OnInit } from '@angular/core';
import { UniversitiesService } from './universities.service';
import { UniversitiesReports } from './universitiesList';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-universities',
  templateUrl: './universities.component.html',
  styleUrls: ['./universities.component.scss']
})
export class UniversitiesComponent implements OnInit {
  ELEMENT_DATA: UniversitiesReports[] = [];
  displayedColumns: string[] = ['alpha_two_code', 'country', 'state-province', 'name'];
  dataSource = new MatTableDataSource<UniversitiesReports>(this.ELEMENT_DATA);

  constructor(private service: UniversitiesService) {


  }

  ngOnInit(): void {
    this.getAllUniversities();
  }

  public getAllUniversities() {
    let resp = this.service.universitiesList();
    resp.subscribe(universities => this.dataSource.data = universities as UniversitiesReports[])
  }

}
