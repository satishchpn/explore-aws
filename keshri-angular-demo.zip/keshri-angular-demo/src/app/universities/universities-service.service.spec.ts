import { TestBed } from '@angular/core/testing';

import { UniversitiesServiceService } from './universities.service';

describe('UniversitiesServiceService', () => {
  let service: UniversitiesServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UniversitiesServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
