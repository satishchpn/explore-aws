export interface UniversitiesReports {
    "alpha_two_code": string;
    country: string;
    "state-province": string;
    name: string;
}