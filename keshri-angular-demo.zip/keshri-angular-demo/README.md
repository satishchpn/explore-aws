# KeshriAngularDemo

## Build

Run `ng build --prod` to build production ready code of the project. The build artifacts will be stored in the `dist/` directory.

