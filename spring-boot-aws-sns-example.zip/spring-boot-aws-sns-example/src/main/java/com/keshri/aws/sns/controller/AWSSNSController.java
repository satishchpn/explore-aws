package com.keshri.aws.sns.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.SubscribeRequest;

@RestController
public class AWSSNSController {

	Logger logger = LoggerFactory.getLogger(AWSSNSController.class);

	@Autowired
	AmazonSNSClient amazonSNSClient;

	@Value("${sns.topic.arn}")
	private String snsTopicARN;

	@GetMapping("/")
	public String welcome() {
		return "Hi Keshri - Welcome to AWS";
	}

	@GetMapping("/addSubscription/{emailId}")
	public String addSubscription(@PathVariable String emailId) {
		SubscribeRequest subscribeRequest = new SubscribeRequest(snsTopicARN, "email", emailId);
		amazonSNSClient.subscribe(subscribeRequest);
		return "Email Subcription requested !!! Please check email to confirm your subscription.";

	}

	@GetMapping("/publish/{payload}")
	public String publishMessageToTopic(@PathVariable String payload) {
		try {
			amazonSNSClient.publish(snsTopicARN, "Test Notification", payload);
			logger.info("Notification Sent Successfully : {}", payload);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return payload;
	}
}
