package com.keshri.aws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeshriSpringBootAwsCrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeshriSpringBootAwsCrudDemoApplication.class, args);
	}

}
