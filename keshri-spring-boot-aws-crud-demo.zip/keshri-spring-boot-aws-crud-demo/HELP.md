Run your docker terminal
Open CMD and type below command
mvn spring-boot:build-image
after successful image creation run below command and check if application is working properly
To see the image type 
docker image ls
docker run --tty --publish 8080:5000 keshri-spring-boot-aws-crud-demo:0.0.1-SNAPSHOT
open browser and see if api is working
<docker_host>:8080
Login to docker account
docker login -u satishchpn
Add tag to docker image using docker username(satishchpn)
docker tag keshri-spring-boot-aws-crud-demo:0.0.1-SNAPSHOT satishchpn/keshri-spring-boot-aws-crud-demo:0.0.1-SNAPSHOT
push image to docker hub
docker push satishchpn/keshri-spring-boot-aws-crud-demo:0.0.1-SNAPSHOT
can see this image in logged in dockerhub dashboard
