package com.keshri.aws.lambda;

public class LambdaMain {

	public static void main(String[] args) {
		System.out.println("LambdaMain executing !!!");
	}

}
