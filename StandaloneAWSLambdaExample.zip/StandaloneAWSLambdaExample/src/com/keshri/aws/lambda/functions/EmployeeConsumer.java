package com.keshri.aws.lambda.functions;

import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.keshri.aws.lambda.model.Employee;

public class EmployeeConsumer implements Consumer<Employee> {

	@Override
	public void accept(Employee employee) {
		Stream.of(new Employee(1, "Satish", "Keshri", "satish@gmail.com"),
				new Employee(1, "Sujit", "Keshri", "sujit@gmail.com"),
				new Employee(1, "Sanjay", "Keshri", "sanjay@gmail.com"),
				new Employee(1, "Sanjiv", "Keshri", "sanjiv@gmail.com")).collect(Collectors.toList()).add(employee);
		System.out.println("Employee added !!!");
	}

}
