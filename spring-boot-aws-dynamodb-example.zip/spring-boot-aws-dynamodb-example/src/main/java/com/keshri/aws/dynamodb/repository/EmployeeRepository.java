package com.keshri.aws.dynamodb.repository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.keshri.aws.dynamodb.entity.Employee;

@Repository
public class EmployeeRepository {

	@Autowired
	DynamoDBMapper dynamoDBMapper;

	public Employee saveEmployee(Employee employee) {
		dynamoDBMapper.save(employee);
		return employee;
	}

	public Employee getEmployeeByEmployeeId(String employeeId) {
		return dynamoDBMapper.load(Employee.class, employeeId);
	}

	public String deleteEmployee(Employee employee) {
		dynamoDBMapper.delete(employee);
		return "Employee Deleted !!!";
	}

	public String updateEmployee(Employee employee) {
		dynamoDBMapper.save(employee, buildExpression(employee));
		return "Employee Updated !!!";
	}

	private DynamoDBSaveExpression buildExpression(Employee employee) {

		DynamoDBSaveExpression expression = new DynamoDBSaveExpression();
		Map<String, ExpectedAttributeValue> expectedMap = new HashMap<String, ExpectedAttributeValue>();
		expectedMap.put("employeeId", new ExpectedAttributeValue(new AttributeValue().withS("")));
		expression.setExpected(expectedMap);
		return expression;

	}

}
