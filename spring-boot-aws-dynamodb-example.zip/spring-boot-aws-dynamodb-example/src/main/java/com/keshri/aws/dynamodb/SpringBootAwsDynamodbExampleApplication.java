package com.keshri.aws.dynamodb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.keshri.aws.dynamodb.entity.Employee;
import com.keshri.aws.dynamodb.repository.EmployeeRepository;

@SpringBootApplication
@RestController
public class SpringBootAwsDynamodbExampleApplication {

	@Autowired
	private EmployeeRepository employeeRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAwsDynamodbExampleApplication.class, args);
	}

	@PostMapping("/employee")
	public Employee saveEmployee(@RequestBody Employee employee) {
		return employeeRepository.saveEmployee(employee);
	}

	@GetMapping("/employee/{employeeId}")
	public Employee getEmployee(@PathVariable String employeeId) {
		return employeeRepository.getEmployeeByEmployeeId(employeeId);
	}

	@PutMapping("/employee")
	public String getEmployee(@RequestBody Employee employee) {
		return employeeRepository.updateEmployee(employee);
	}

	@DeleteMapping("/employee")
	public String deleteEmployee(@RequestBody Employee employee) {
		return employeeRepository.deleteEmployee(employee);
	}

}
